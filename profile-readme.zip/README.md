# Hi, I'm Vaibhav Jain 👋

**Green-transition engineer** working where energy systems, electronics and business meet.
MSc Energy for Smart Cities (KU Leuven & KTH, EIT InnoEnergy scholarship) · BTech Electronics & Communication.

> *Mars is great, but Earth is present.*

🌐 [vbhvjain.netlify.app](https://vbhvjain.netlify.app) · 💼 [LinkedIn](https://linkedin.com/in/vbhvjain) · 📍 Stockholm

## Selected projects

| Project | Area | What it does |
|---|---|---|
| AI waste-volume estimation (MSc thesis, Local Life AB) | Computer vision | YOLO + depth estimation on an RGB-D camera; cut volume-estimation error from 43.2% to 13.2% |
| Price-based load shifting | Energy flexibility | Moves flexible demand to low-price hours using consumption and price data |
| Power electronics & EV drive models | MATLAB/Simulink | Converters, PWM inverter, EV drive and BMS simulations (course grade 18/20) |
| Life-cycle assessment of a 50 MWh BESS | Sustainability | Second-life vs recycling; found a pathway with 40.7% lower carbon footprint |
| Cattle Care Monitoring System | ESP32 IoT | Feed weight, water level with servo auto-refill, humidity/CO₂/gas sensing over Wi-Fi |
| Solar tracker (ISRO PRL) | Hardware | Motor-driven tracker: component selection, wiring, programming, commissioning |
| AI-agent research workflows | Automation | Market and company data collection on 400+ companies with Claude Code and Apify |
| [Personal website](https://vbhvjain.netlify.app) | Web | Interactive single-page site with a projects gallery |

## Tools
Python · MATLAB/Simulink · ESP32 / Arduino · SQL · Excel · Power BI · Git · Claude Code · Apify
